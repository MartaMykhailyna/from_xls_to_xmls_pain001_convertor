pain001 package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pain001.constants
   pain001.context
   pain001.core

Module contents
---------------

.. automodule:: pain001
   :members:
   :undoc-members:
   :show-inheritance:
